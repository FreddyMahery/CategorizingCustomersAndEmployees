# -*- coding: utf-8 -*-

from . import client_category
from . import client
from . import predominant_category